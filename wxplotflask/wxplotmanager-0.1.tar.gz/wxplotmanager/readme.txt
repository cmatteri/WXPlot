Installation instructions:

1) Run the installer:

wee_extension --install=constantintervalmanager-0.1.tar.gz

Manual installation instructions:

1) Copy files to the weewx user directory:

# See http://weewx.com/docs/usersguide.htm#Where_to_find_things
# for location of BIN_ROOT

tar xf constantintervalmanager-0.1.tar.gz
cp constantintervalmanager/bin/user/constantintervalmanager.py BIN_ROOT/user

2) Update data binding in weewx.conf:

[DataBindings]
    [[wx_binding]]
        manager = user.constantintervalmanager.ConstantIntervalManager